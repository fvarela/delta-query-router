import React, { useState, useEffect } from "react";
import { mockApi } from "@/mocks/api";
import { useAuth, useApp } from "@/contexts/AppContext";
import { LoadingSpinner } from "@/components/shared/LoadingSpinner";
import type { CatalogInfo, SchemaInfo, TableInfo } from "@/types";
import { ChevronRight, ChevronDown, Folder, Table2, Database } from "lucide-react";

const formatBytes = (b: number | null) => {
  if (!b) return "-";
  if (b < 1024 * 1024) return `${(b / 1024).toFixed(0)} KB`;
  if (b < 1024 * 1024 * 1024) return `${(b / (1024 * 1024)).toFixed(1)} MB`;
  return `${(b / (1024 * 1024 * 1024)).toFixed(1)} GB`;
};

const formatNumber = (n: number | null) => n == null ? "-" : n.toLocaleString();

export const CatalogBrowser: React.FC = () => {
  const { token } = useAuth();
  const { isDatabricksConfigured, setEditorSql, setCollectionContext } = useApp();
  const [catalogs, setCatalogs] = useState<CatalogInfo[]>([]);
  const [expanded, setExpanded] = useState<Record<string, boolean>>({});
  const [schemas, setSchemas] = useState<Record<string, SchemaInfo[]>>({});
  const [tables, setTables] = useState<Record<string, TableInfo[]>>({});
  const [loadingKeys, setLoadingKeys] = useState<Set<string>>(new Set());
  const [selectedTable, setSelectedTable] = useState<TableInfo | null>(null);

  useEffect(() => {
    if (!token || !isDatabricksConfigured) return;
    setLoadingKeys(new Set(["catalogs"]));
    mockApi.getCatalogs(token).then(c => {
      setCatalogs(c);
      setLoadingKeys(prev => { const n = new Set(prev); n.delete("catalogs"); return n; });
    });
  }, [token, isDatabricksConfigured]);

  const toggleCatalog = async (catalog: string) => {
    const key = catalog;
    if (expanded[key]) {
      setExpanded(prev => ({ ...prev, [key]: false }));
      return;
    }
    if (!schemas[catalog] && token) {
      setLoadingKeys(prev => new Set(prev).add(key));
      const s = await mockApi.getSchemas(token, catalog);
      setSchemas(prev => ({ ...prev, [catalog]: s }));
      setLoadingKeys(prev => { const n = new Set(prev); n.delete(key); return n; });
    }
    setExpanded(prev => ({ ...prev, [key]: true }));
  };

  const toggleSchema = async (catalog: string, schema: string) => {
    const key = `${catalog}.${schema}`;
    if (expanded[key]) {
      setExpanded(prev => ({ ...prev, [key]: false }));
      return;
    }
    if (!tables[key] && token) {
      setLoadingKeys(prev => new Set(prev).add(key));
      const t = await mockApi.getTables(token, catalog, schema);
      setTables(prev => ({ ...prev, [key]: t }));
      setLoadingKeys(prev => { const n = new Set(prev); n.delete(key); return n; });
    }
    setExpanded(prev => ({ ...prev, [key]: true }));
  };

  const handleTableClick = (table: TableInfo) => {
    setSelectedTable(selectedTable?.full_name === table.full_name ? null : table);
  };

  const handleLoadSample = (table: TableInfo) => {
    setEditorSql(`SELECT * FROM ${table.full_name} LIMIT 100`);
    setCollectionContext(null);
  };

  if (!isDatabricksConfigured) {
    return (
      <div className="p-3 text-muted-foreground text-[12px]">
        Connect to Databricks in Settings to browse catalogs.
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      <div className="px-3 py-2 border-b border-panel-border text-[12px] font-semibold text-foreground">Unity Catalog</div>
      <div className="flex-1 overflow-y-auto text-[12px]">
        {loadingKeys.has("catalogs") && <div className="p-3"><LoadingSpinner /></div>}
        {catalogs.map(cat => (
          <div key={cat.name}>
            <button onClick={() => toggleCatalog(cat.name)} className="flex items-center gap-1 w-full px-3 py-1 hover:bg-muted text-left text-foreground">
              {expanded[cat.name] ? <ChevronDown size={12} /> : <ChevronRight size={12} />}
              <Database size={12} className="text-primary" />
              <span>{cat.name}</span>
            </button>
            {loadingKeys.has(cat.name) && <div className="pl-8 py-1"><LoadingSpinner size={12} /></div>}
            {expanded[cat.name] && schemas[cat.name]?.map(sch => (
              <div key={sch.name}>
                <button onClick={() => toggleSchema(cat.name, sch.name)} className="flex items-center gap-1 w-full pl-6 pr-3 py-1 hover:bg-muted text-left text-foreground">
                  {expanded[`${cat.name}.${sch.name}`] ? <ChevronDown size={12} /> : <ChevronRight size={12} />}
                  <Folder size={12} className="text-primary" />
                  <span>{sch.name}</span>
                </button>
                {loadingKeys.has(`${cat.name}.${sch.name}`) && <div className="pl-12 py-1"><LoadingSpinner size={12} /></div>}
                {expanded[`${cat.name}.${sch.name}`] && tables[`${cat.name}.${sch.name}`]?.map(tbl => (
                  <button
                    key={tbl.name}
                    onClick={() => handleTableClick(tbl)}
                    className={`flex items-center gap-1 w-full pl-10 pr-3 py-1 hover:bg-muted text-left ${
                      selectedTable?.full_name === tbl.full_name ? "bg-muted" : ""
                    }`}
                  >
                    <div className={`w-1 h-4 rounded-sm mr-1 ${tbl.external_engine_read_support ? "bg-status-success" : "bg-status-warning"}`} />
                    <Table2 size={12} className="text-muted-foreground" />
                    <span className="text-foreground">{tbl.name}</span>
                  </button>
                ))}
              </div>
            ))}
          </div>
        ))}
      </div>

      {/* Table Detail */}
      {selectedTable && (
        <div className="border-t border-panel-border p-3 overflow-y-auto text-[11px] max-h-[50%]">
          <h4 className="font-semibold text-[12px] mb-2 text-foreground">{selectedTable.full_name}</h4>
          <div className="space-y-1 text-muted-foreground">
            <p><span className="font-medium text-foreground">Type:</span> {selectedTable.table_type}</p>
            {selectedTable.data_source_format && <p><span className="font-medium text-foreground">Format:</span> {selectedTable.data_source_format}</p>}
            <p><span className="font-medium text-foreground">Size:</span> {formatBytes(selectedTable.size_bytes)}</p>
            <p><span className="font-medium text-foreground">Rows:</span> {formatNumber(selectedTable.row_count)}</p>
            {selectedTable.storage_location && <p><span className="font-medium text-foreground">Location:</span> {selectedTable.storage_location}</p>}
            <p>
              <span className="font-medium text-foreground">DuckDB Readable:</span>{" "}
              {selectedTable.external_engine_read_support
                ? <span className="text-status-success">Yes</span>
                : <span className="text-status-warning">No — {selectedTable.read_support_reason}</span>}
            </p>
          </div>
          <div className="mt-2">
            <p className="font-medium text-foreground mb-1">Columns</p>
            <div className="space-y-0.5">
              {selectedTable.columns.map(c => (
                <div key={c.name} className="flex justify-between text-muted-foreground">
                  <span className="font-mono">{c.name}</span>
                  <span className="font-mono text-[10px]">{c.type_text}</span>
                </div>
              ))}
            </div>
          </div>
          <button
            onClick={() => handleLoadSample(selectedTable)}
            className="mt-2 px-3 py-1 bg-primary text-primary-foreground rounded text-[11px] font-medium"
          >
            Load Sample Query
          </button>
        </div>
      )}
    </div>
  );
};
